'use client';

import { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Page1Welcome } from '@/components/pages/Page1Welcome';
import { Page2Request } from '@/components/pages/Page2Request';
import { Page3Friendship } from '@/components/pages/Page3Friendship';
import { Page4Letter } from '@/components/pages/Page4Letter';
import { Page5Reasons } from '@/components/pages/Page5Reasons';
import { Page6Promises } from '@/components/pages/Page6Promises';
import { Page7Suspense } from '@/components/pages/Page7Suspense';
import { Page8Proposal } from '@/components/pages/Page8Proposal';
import { Page9Questions } from '@/components/pages/Page9Questions';
import { Page10Finale } from '@/components/pages/Page10Finale';

export default function Home() {
  const [currentPage, setCurrentPage] = useState(0);
  const [answers, setAnswers] = useState<Record<string, boolean>>({});
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    // Disable scrolling
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  if (!isClient) {
    return null;
  }

  const handleNextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  const handleYesProposal = () => {
    setCurrentPage(8); // Go to page 9 (questions)
  };

  const handleFinishQuestions = (newAnswers: Record<string, boolean>) => {
    setAnswers(newAnswers);
    setCurrentPage(9); // Go to page 10 (finale)
  };

  const pages = [
    <Page1Welcome key="page1" onNext={handleNextPage} />,
    <Page2Request key="page2" onNext={handleNextPage} />,
    <Page3Friendship key="page3" onNext={handleNextPage} />,
    <Page4Letter key="page4" onNext={handleNextPage} />,
    <Page5Reasons key="page5" onNext={handleNextPage} />,
    <Page6Promises key="page6" onNext={handleNextPage} />,
    <Page7Suspense key="page7" onNext={handleNextPage} />,
    <Page8Proposal
      key="page8"
      onYes={handleYesProposal}
      onNo={() => setCurrentPage(0)}
    />,
    <Page9Questions key="page9" onFinish={handleFinishQuestions} />,
    <Page10Finale key="page10" answers={answers} />,
  ];

  return (
    <div className="w-full h-screen overflow-hidden bg-gradient-to-br from-pink-100 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-purple-900 dark:to-gray-900">
      <AnimatePresence mode="wait">
        {pages[currentPage]}
      </AnimatePresence>
    </div>
  );
}
