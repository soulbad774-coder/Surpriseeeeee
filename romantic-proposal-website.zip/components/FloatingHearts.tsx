'use client';

import { motion } from 'framer-motion';

export function FloatingHearts() {
  const hearts = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    delay: Math.random() * 0.5,
    duration: 4 + Math.random() * 2,
    left: Math.random() * 100,
    size: 20 + Math.random() * 30,
  }));

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      {hearts.map((heart) => (
        <motion.div
          key={heart.id}
          className="absolute text-rose-500 opacity-60"
          style={{
            left: `${heart.left}%`,
            fontSize: `${heart.size}px`,
          }}
          initial={{ y: '100vh', rotate: 0 }}
          animate={{ y: '-100vh', rotate: 360 }}
          transition={{
            duration: heart.duration,
            delay: heart.delay,
            repeat: Infinity,
            ease: 'easeIn',
          }}
        >
          ❤️
        </motion.div>
      ))}
    </div>
  );
}
