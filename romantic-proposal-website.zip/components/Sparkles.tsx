'use client';

import { motion } from 'framer-motion';

export function Sparkles() {
  const sparkles = Array.from({ length: 12 }).map((_, i) => ({
    id: i,
    delay: Math.random() * 0.8,
    duration: 2 + Math.random() * 1.5,
    left: Math.random() * 100,
    top: Math.random() * 100,
  }));

  return (
    <div className="pointer-events-none fixed inset-0">
      {sparkles.map((sparkle) => (
        <motion.div
          key={sparkle.id}
          className="absolute text-yellow-300 text-lg"
          style={{
            left: `${sparkle.left}%`,
            top: `${sparkle.top}%`,
          }}
          animate={{ opacity: [0, 1, 0], scale: [0, 1, 0] }}
          transition={{
            duration: sparkle.duration,
            delay: sparkle.delay,
            repeat: Infinity,
          }}
        >
          ✨
        </motion.div>
      ))}
    </div>
  );
}
