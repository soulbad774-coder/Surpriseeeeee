'use client';

import { motion } from 'framer-motion';

interface GlowingButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'accent';
  disabled?: boolean;
}

export function GlowingButton({
  children,
  onClick,
  className = '',
  variant = 'primary',
  disabled = false,
}: GlowingButtonProps) {
  const variantClasses = {
    primary: 'bg-rose-500 hover:bg-rose-600 shadow-[0_0_20px_rgba(244,114,182,0.5)]',
    secondary: 'bg-purple-600 hover:bg-purple-700 shadow-[0_0_20px_rgba(168,85,247,0.5)]',
    accent: 'bg-amber-500 hover:bg-amber-600 shadow-[0_0_20px_rgba(244,164,96,0.5)]',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      disabled={disabled}
      className={`px-8 py-4 rounded-full font-semibold text-white transition-all duration-300 ${variantClasses[variant]} ${className} ${
        disabled ? 'opacity-50 cursor-not-allowed' : ''
      }`}
    >
      {children}
    </motion.button>
  );
}
