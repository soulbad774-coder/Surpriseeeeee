'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page3FriendshipProps {
  onNext: () => void;
}

export function Page3Friendship({ onNext }: Page3FriendshipProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <PageWrapper>
      <motion.div className="text-center max-w-3xl mx-auto px-4">
        <motion.h1
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="text-5xl md:text-6xl font-bold mb-10 text-rose-500"
        >
          Our Friendship Story
        </motion.h1>

        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="bg-gradient-to-r from-rose-50/50 to-purple-50/50 dark:from-rose-950/20 dark:to-purple-950/20 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-rose-200/30 dark:border-rose-800/30 space-y-6"
        >
          <motion.p variants={itemVariants} className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed italic">
            From the very first conversation, I never imagined that one day you would become one of
            the most important people in my life.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed"
          >
            We started as friends, sharing random conversations, laughter, little arguments, and
            countless memories. Without realizing it, you became the person I looked forward to
            talking to every day.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed"
          >
            Some people enter our lives for a moment, but you became a part of mine. Every memory
            with you is something I'll always treasure.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed italic font-semibold text-rose-600 dark:text-rose-400"
          >
            And somewhere between all those conversations, my friendship quietly turned into love.
          </motion.p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-12"
        >
          <GlowingButton onClick={onNext} variant="primary">
            Next
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
