'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page5ReasonsProps {
  onNext: () => void;
}

export function Page5Reasons({ onNext }: Page5ReasonsProps) {
  const reasons = [
    'Your smile makes everything feel better.',
    'You make ordinary conversations unforgettable.',
    'You are kind and caring.',
    'You understand me.',
    'You stay on my mind.',
    'I can be myself with you.',
    'You inspire me.',
    'You make me happy.',
    'You are unique.',
    'Simply because you&apos;re Abiroo.',
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.8, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <PageWrapper>
      <motion.div className="max-w-5xl mx-auto px-4 w-full">
        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-6xl font-bold mb-12 text-center text-rose-500"
        >
          Why I Love You
        </motion.h1>

        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              variants={cardVariants}
              className="bg-gradient-to-br from-rose-100/40 to-purple-100/40 dark:from-rose-900/20 dark:to-purple-900/20 backdrop-blur-md rounded-2xl p-6 border border-rose-200/30 dark:border-rose-800/30 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-4">
                <span className="text-4xl">✨</span>
                <p className="text-lg text-gray-800 dark:text-gray-100 font-medium">{reason}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="mt-12 text-center"
        >
          <GlowingButton onClick={onNext} variant="primary">
            Next
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
