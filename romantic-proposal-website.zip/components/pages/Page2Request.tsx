'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page2RequestProps {
  onNext: () => void;
}

export function Page2Request({ onNext }: Page2RequestProps) {
  return (
    <PageWrapper>
      <motion.div className="text-center max-w-2xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-6xl font-bold mb-8 text-rose-500"
        >
          A Small Request
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="bg-gradient-to-r from-rose-100/40 to-purple-100/40 dark:from-rose-900/20 dark:to-purple-900/20 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-rose-200/30 dark:border-rose-800/30"
        >
          <p className="text-lg md:text-xl text-gray-800 dark:text-gray-100 leading-relaxed">
            Please don't leave this website until the end. Every page has been made with love
            especially for you.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12"
        >
          <GlowingButton onClick={onNext} variant="primary">
            Next
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
