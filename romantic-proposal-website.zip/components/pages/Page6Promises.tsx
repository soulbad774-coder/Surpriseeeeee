'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page6PromisesProps {
  onNext: () => void;
}

export function Page6Promises({ onNext }: Page6PromisesProps) {
  const promises = [
    'Respect you.',
    'Always be honest.',
    'Support you.',
    'Stay beside you.',
    'Make you smile.',
    'Appreciate you.',
    'Protect your trust.',
    'Love you with all my heart.',
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <PageWrapper>
      <motion.div className="max-w-3xl mx-auto px-4 w-full">
        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-6xl font-bold mb-12 text-center text-rose-500"
        >
          My Promises
        </motion.h1>

        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="bg-gradient-to-r from-rose-50/50 to-purple-50/50 dark:from-rose-950/20 dark:to-purple-950/20 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-rose-200/30 dark:border-rose-800/30 space-y-4"
        >
          {promises.map((promise, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="flex items-center gap-4"
            >
              <span className="text-2xl text-rose-500">✓</span>
              <p className="text-lg text-gray-800 dark:text-gray-100 font-medium">
                I promise to {promise}
              </p>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-12 text-center"
        >
          <GlowingButton onClick={onNext} variant="primary">
            Next
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
