'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page7SuspenseProps {
  onNext: () => void;
}

export function Page7Suspense({ onNext }: Page7SuspenseProps) {
  const textVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const charVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { duration: 0.1 },
    },
  };

  const text = 'There is only one question left...';

  return (
    <PageWrapper>
      <motion.div className="text-center max-w-2xl mx-auto px-4">
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-9xl mb-12"
        >
          💗
        </motion.div>

        <motion.div variants={textVariants} initial="hidden" animate="visible" className="mb-12">
          <p className="text-4xl md:text-5xl font-bold text-rose-600 dark:text-rose-400">
            {text.split('').map((char, index) => (
              <motion.span key={index} variants={charVariants}>
                {char}
              </motion.span>
            ))}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <GlowingButton onClick={onNext} variant="secondary">
            Continue 💕
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
