'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page10FinaleProps {
  answers: Record<string, boolean>;
}

export function Page10Finale({ answers }: Page10FinaleProps) {
  const [showPopup, setShowPopup] = useState(false);
  const [copied, setCopied] = useState(false);

  const answersText = `Voice Note: ${answers['Will you send me a voice note?'] ? 'Yes' : 'No'}
Waist Photo: ${answers['Will you send me your waist photo?'] ? 'Yes' : 'No'}
Photo: ${answers['Will you send me your photo?'] ? 'Yes' : 'No'}
Mole Photo: ${answers['Will you send me a photo of your mole (til)?'] ? 'Yes' : 'No'}
Fit Check: ${answers['Will you send me a fit check photo?'] ? 'Yes' : 'No'}`;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(answersText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const floatingHearts = Array.from({ length: 20 }).map((_, i) => ({
    id: i,
    delay: Math.random() * 0.5,
    left: Math.random() * 100,
  }));

  return (
    <PageWrapper>
      <div className="relative w-full">
        {/* Confetti/falling hearts */}
        <div className="pointer-events-none fixed inset-0">
          {floatingHearts.map((heart) => (
            <motion.div
              key={heart.id}
              className="absolute text-rose-500 text-3xl"
              style={{ left: `${heart.left}%` }}
              animate={{
                y: ['-100vh', '100vh'],
                rotate: [0, 360],
              }}
              transition={{
                duration: 4 + Math.random() * 2,
                delay: heart.delay,
                repeat: Infinity,
              }}
            >
              ❤️
            </motion.div>
          ))}
        </div>

        <motion.div className="text-center max-w-2xl mx-auto px-4">
          <motion.h1
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-6xl font-bold mb-8 text-rose-500"
          >
            Thank you for accepting my proposal ❤️
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-gradient-to-r from-rose-50/50 to-purple-50/50 dark:from-rose-950/20 dark:to-purple-950/20 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-rose-200/30 dark:border-rose-800/30 space-y-6"
          >
            <p className="text-xl text-gray-800 dark:text-gray-100 leading-relaxed">
              You have just made me the happiest person in the world.
            </p>

            <p className="text-xl text-gray-800 dark:text-gray-100 leading-relaxed">
              I promise to cherish, respect, and love you with all my heart.
            </p>

            <p className="text-xl text-gray-800 dark:text-gray-100 leading-relaxed">
              This is the beginning of a beautiful journey, and I can't wait to create countless
              memories with you.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-12"
          >
            <GlowingButton onClick={() => setShowPopup(true)} variant="primary">
              Continue 💕
            </GlowingButton>
          </motion.div>
        </motion.div>
      </div>

      {/* Popup */}
      {showPopup && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          onClick={() => setShowPopup(false)}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-gray-900 rounded-3xl p-8 max-w-md w-full shadow-2xl border border-rose-200/30 dark:border-rose-800/30"
            onClick={(e) => e.stopPropagation()}
          >
            <motion.h2 className="text-3xl font-bold mb-6 text-rose-500 text-center">
              Thank You ❤️
            </motion.h2>

            <p className="text-lg text-gray-800 dark:text-gray-100 mb-8 text-center">
              Copy your answers and send them to me on Instagram.
            </p>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleCopy}
              className="w-full bg-gradient-to-r from-rose-500 to-purple-500 hover:from-rose-600 hover:to-purple-600 text-white font-bold py-4 rounded-full transition-all"
            >
              {copied ? '✓ Copied Successfully ❤️' : '📋 Copy My Answers'}
            </motion.button>

            {copied && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center mt-4 text-green-600 dark:text-green-400 font-semibold"
              >
                Copied to clipboard!
              </motion.p>
            )}

            <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded-2xl max-h-40 overflow-y-auto">
              <p className="text-sm text-gray-700 dark:text-gray-200 whitespace-pre-wrap font-mono">
                {answersText}
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </PageWrapper>
  );
}
