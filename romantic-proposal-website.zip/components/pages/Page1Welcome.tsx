'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page1WelcomeProps {
  onNext: () => void;
}

export function Page1Welcome({ onNext }: Page1WelcomeProps) {
  return (
    <PageWrapper>
      <motion.div className="text-center max-w-2xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-rose-500 via-purple-500 to-pink-500 bg-clip-text text-transparent"
        >
          Hi Abiroo ❤️
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-xl md:text-2xl text-gray-700 dark:text-gray-200 mb-12 leading-relaxed"
        >
          I made something very special just for you.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <GlowingButton onClick={onNext} variant="primary">
            Begin Our Journey 💕
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
