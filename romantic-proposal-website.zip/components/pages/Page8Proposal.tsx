'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page8ProposalProps {
  onYes: () => void;
  onNo: () => void;
}

export function Page8Proposal({ onYes, onNo }: Page8ProposalProps) {
  const [showReject, setShowReject] = useState(false);

  return (
    <PageWrapper>
      <motion.div className="text-center max-w-2xl mx-auto px-4">
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="text-9xl md:text-10xl mb-12"
        >
          💗
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-12 text-rose-500"
        >
          Will You Be My Girlfriend?
        </motion.h1>

        {!showReject && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <GlowingButton onClick={onYes} variant="primary">
              ❤️ YES
            </GlowingButton>
            <GlowingButton
              onClick={() => setShowReject(true)}
              variant="secondary"
            >
              💔 NO
            </GlowingButton>
          </motion.div>
        )}

        {showReject && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.p
              className="text-xl md:text-2xl text-gray-700 dark:text-gray-200 leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1 }}
            >
              I'll always respect your decision. Thank you for taking this journey with me.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              <GlowingButton onClick={() => setShowReject(false)} variant="accent">
                Go Back
              </GlowingButton>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
    </PageWrapper>
  );
}
