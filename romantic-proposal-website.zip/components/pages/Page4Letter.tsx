'use client';

import { motion } from 'framer-motion';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page4LetterProps {
  onNext: () => void;
}

export function Page4Letter({ onNext }: Page4LetterProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <PageWrapper>
      <motion.div className="text-center max-w-3xl mx-auto px-4">
        <motion.h1
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="text-5xl md:text-6xl font-bold mb-10 text-rose-500"
        >
          A Letter From My Heart
        </motion.h1>

        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="bg-gradient-to-r from-rose-50/50 to-purple-50/50 dark:from-rose-950/20 dark:to-purple-950/20 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-rose-200/30 dark:border-rose-800/30 space-y-6 text-left"
        >
          <motion.p variants={itemVariants} className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed font-semibold">
            Dear Abiroo,
          </motion.p>

          <motion.p variants={itemVariants} className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed">
            There are countless people in this world, but somehow my heart chose you.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed"
          >
            You make ordinary days feel special, and your presence brings peace in a way words
            can't fully explain. Every smile from you, every conversation, and every little moment
            we've shared has become a memory I'll always cherish.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed"
          >
            I don't know what the future holds, but I do know one thing—I want you to be a part of
            it.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed"
          >
            Today, I'm not just expressing my feelings. I'm opening my heart to the person who
            means the most to me.
          </motion.p>

          <motion.p
            variants={itemVariants}
            className="text-lg text-gray-800 dark:text-gray-100 leading-relaxed italic font-semibold text-rose-600 dark:text-rose-400"
          >
            No matter what your answer is, you'll always be someone I'll respect and care about.
          </motion.p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-12"
        >
          <GlowingButton onClick={onNext} variant="primary">
            Next
          </GlowingButton>
        </motion.div>
      </motion.div>
    </PageWrapper>
  );
}
