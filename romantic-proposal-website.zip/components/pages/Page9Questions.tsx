'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { PageWrapper } from '../PageWrapper';
import { GlowingButton } from '../GlowingButton';

interface Page9QuestionsProps {
  onFinish: (answers: Record<string, boolean>) => void;
}

export function Page9Questions({ onFinish }: Page9QuestionsProps) {
  const questions = [
    'Will you send me a voice note?',
    'Will you send me your waist photo?',
    'Will you send me your photo?',
    'Will you send me a photo of your mole (til)?',
    'Will you send me a fit check photo?',
  ];

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, boolean>>({});

  const handleAnswer = (answer: boolean) => {
    setAnswers({
      ...answers,
      [questions[currentQuestion]]: answer,
    });

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      onFinish(answers);
    }
  };

  const questionLabels = [
    'Voice Note',
    'Waist Photo',
    'Photo',
    'Mole Photo',
    'Fit Check Photo',
  ];

  return (
    <PageWrapper>
      <motion.div className="text-center max-w-2xl mx-auto px-4 w-full">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-6"
        >
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Question {currentQuestion + 1} of {questions.length}
          </p>
          <div className="w-full h-1 bg-gray-200 dark:bg-gray-700 rounded-full mt-4">
            <motion.div
              className="h-1 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        <motion.h2
          key={currentQuestion}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl md:text-5xl font-bold mb-12 text-rose-500"
        >
          {questions[currentQuestion]}
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col sm:flex-row gap-6 justify-center"
        >
          <GlowingButton onClick={() => handleAnswer(true)} variant="primary">
            YES
          </GlowingButton>
          <GlowingButton onClick={() => handleAnswer(false)} variant="secondary">
            NO
          </GlowingButton>
        </motion.div>

        {currentQuestion === questions.length - 1 && Object.keys(answers).length === questions.length - 1 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-8 text-sm text-gray-600 dark:text-gray-400"
          >
            <p>Almost done! Answer this last question to finish.</p>
          </motion.div>
        )}
      </motion.div>
    </PageWrapper>
  );
}
