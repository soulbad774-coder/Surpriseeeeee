'use client';

import { motion } from 'framer-motion';
import { Footer } from './Footer';
import { FloatingHearts } from './FloatingHearts';

interface PageWrapperProps {
  children: React.ReactNode;
  animate?: boolean;
}

export function PageWrapper({ children, animate = true }: PageWrapperProps) {
  return (
    <motion.div
      initial={animate ? { opacity: 0, y: 20 } : false}
      animate={animate ? { opacity: 1, y: 0 } : false}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen w-full flex flex-col items-center justify-center pb-20"
    >
      <FloatingHearts />
      {children}
      <Footer />
    </motion.div>
  );
}
