'use client';

export function Footer() {
  return (
    <footer className="fixed bottom-0 left-0 right-0 py-4 text-center text-sm text-gray-600 dark:text-gray-400 backdrop-blur-sm">
      Website made by Ahsaan with love for Abiroo ❤️
    </footer>
  );
}
