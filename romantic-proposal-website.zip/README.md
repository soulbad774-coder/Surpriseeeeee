# 💕 Premium Romantic Proposal Website

A luxury, fully responsive romantic proposal website made with love for Abiroo by Ahsaan.

## ✨ Features

### 🎨 Design & Aesthetics
- **Premium Romantic Theme**: Elegant gradient backgrounds with soft pink, purple, gold, and white colors
- **Glassmorphism Cards**: Frosted glass effect with backdrop blur for modern elegance
- **Smooth Animations**: Framer Motion animations for page transitions and interactive elements
- **Floating Hearts**: Animated hearts falling continuously in the background
- **Sparkle Effects**: Twinkling sparkles throughout the experience
- **Glowing Buttons**: Beautiful glowing effects on all interactive elements

### 📱 Responsive Design
- **Mobile-First Approach**: Optimized for iPhone, Android, tablets, and desktops
- **Full-Screen Pages**: Each page takes up the entire screen for immersive experience
- **Touch-Friendly**: Large buttons and easy navigation on all devices
- **No Scrolling**: Users navigate only through provided buttons

### 🎭 Multi-Page Experience (10 Pages)
1. **Welcome Page** - Warm greeting: "Hi Abiroo ❤️"
2. **A Small Request** - Please don't leave until the end
3. **Our Friendship Story** - How the relationship started
4. **A Letter From My Heart** - Deep emotional message
5. **Why I Love You** - 10 animated reason cards
6. **My Promises** - 8 heartfelt promises
7. **Suspense** - Typewriter text animation
8. **Proposal** - The big question with YES/NO options
9. **Questions** - 5 interactive questions with YES/NO answers
10. **Final Surprise** - Celebration with confetti and popup for copying answers

### 🎯 Key Interactions
- **Next Buttons**: Smooth page transitions
- **Proposal Decision**: Handle YES/NO responses gracefully
- **Question Answers**: Track and save all responses
- **Copy Answers**: One-click copy to clipboard for Instagram sharing

### 🎼 Technical Stack
- **Framework**: Next.js 16 with App Router
- **Animations**: Framer Motion for smooth transitions
- **Styling**: Tailwind CSS with custom gradient backgrounds
- **Color System**: Luxury romantic color palette
  - Primary: Rose Pink (#d4375f)
  - Secondary: Deep Purple (#b8176f)
  - Accent: Gold (#f4a460)
  - Backgrounds: Soft gradients with transparency

## 🚀 Getting Started

### Installation
```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev
```

The app will be available at `http://localhost:3000`

### Build & Deploy
```bash
# Production build
pnpm build

# Start production server
pnpm start
```

## 📁 Project Structure

```
/app
  ├── page.tsx              # Main orchestrator component
  ├── layout.tsx            # Root layout with metadata
  └── globals.css           # Global styles and animations

/components
  ├── FloatingHearts.tsx    # Falling heart animation
  ├── Sparkles.tsx          # Sparkle effect animation
  ├── GlowingButton.tsx     # Interactive button component
  ├── PageWrapper.tsx       # Page container with animations
  ├── Footer.tsx            # Footer with creator credit
  └── /pages
      ├── Page1Welcome.tsx       # Welcome page
      ├── Page2Request.tsx       # Request page
      ├── Page3Friendship.tsx    # Friendship story
      ├── Page4Letter.tsx        # Letter from heart
      ├── Page5Reasons.tsx       # Why I love you
      ├── Page6Promises.tsx      # My promises
      ├── Page7Suspense.tsx      # Suspense page
      ├── Page8Proposal.tsx      # Proposal question
      ├── Page9Questions.tsx     # Interactive questions
      └── Page10Finale.tsx       # Final celebration
```

## 🎨 Customization

### Change Color Scheme
Edit `/app/globals.css` to modify the romantic color palette:
```css
:root {
  --primary: #d4375f;      /* Change primary color */
  --secondary: #b8176f;    /* Change secondary color */
  --accent: #f4a460;       /* Change accent color */
}
```

### Modify Text Content
Each page component has editable text. Update the strings in:
- `/components/pages/Page*.tsx`

### Adjust Animations
Modify animation speeds and effects in:
- `/app/globals.css` - Global keyframe animations
- `/components/FloatingHearts.tsx` - Heart animation settings
- `/components/Sparkles.tsx` - Sparkle animation settings

## 📊 Performance

- **Optimized for Speed**: No external images by default (all generated/emoji-based)
- **Smooth 60fps Animations**: GPU-accelerated with Framer Motion
- **Fast Page Transitions**: Instant loading between pages
- **Mobile-Optimized**: Minimal bundle size, optimized for touch

## 🎁 Features by Page

### Page 5 - Why I Love You
Displays 10 beautiful animated cards with reasons, each appearing with a stagger effect.

### Page 8 - Proposal
- Main question: "Will You Be My Girlfriend?"
- YES button: Proceeds to questions
- NO button: Shows respectful message with option to go back

### Page 9 - Questions
Progressive questions appear one by one:
1. Will you send me a voice note?
2. Will you send me your waist photo?
3. Will you send me your photo?
4. Will you send me a photo of your mole (til)?
5. Will you send me a fit check photo?

Answers are tracked and can be copied to clipboard.

### Page 10 - Final Celebration
- Falling hearts animation throughout
- Celebration message
- Popup to copy answers in formatted text
- Share-ready format for Instagram

## 📝 Footer
Every page displays: "Website made by Ahsaan with love for Abiroo ❤️"

## 🌐 Browser Support
- Chrome/Edge: Latest
- Firefox: Latest
- Safari: Latest (iOS 14+)
- Mobile browsers: All modern versions

## 🎯 Tips for Using

1. **Full Screen Experience**: Open in full screen for best experience
2. **No Interruptions**: Scrolling is disabled - navigate only with buttons
3. **Beautiful on All Devices**: Works perfectly on any screen size
4. **Share Answers**: Copy answers from final page to share on Instagram

## 💫 Special Details

- **Smooth Transitions**: Each page has fade-in animations
- **Responsive Typography**: Text scales beautifully on all devices
- **Touch Optimized**: Buttons are large enough for easy tapping
- **Romantic Atmosphere**: Floating hearts and sparkles create magical ambiance
- **No Music**: Clean, distraction-free experience as requested

## 🚀 Deployment

Ready to deploy to Vercel:

```bash
# Using Vercel CLI
vercel deploy

# Or push to GitHub and connect to Vercel
```

The website will automatically deploy and scale perfectly across all devices.

---

Made with ❤️ for a special someone.
